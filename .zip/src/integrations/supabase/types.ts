export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      bookings: {
        Row: {
          booking_status: string
          booking_type: string
          check_in_date: string | null
          check_out_date: string | null
          created_at: string
          estimated_km: number | null
          hotel_id: string | null
          id: string
          number_of_nights: number | null
          number_of_persons: number | null
          payment_method: string
          rental_end_date: string | null
          rental_start_date: string | null
          board_type: string | null
          room_type: string | null
          service_charge: number
          subtotal: number
          total_amount: number
          updated_at: string
          user_id: string
          vehicle_id: string | null
        }
        Insert: {
          board_type?: string | null
          booking_status?: string
          booking_type: string
          check_in_date?: string | null
          check_out_date?: string | null
          created_at?: string
          estimated_km?: number | null
          hotel_id?: string | null
          id?: string
          number_of_nights?: number | null
          number_of_persons?: number | null
          payment_method?: string
          rental_end_date?: string | null
          rental_start_date?: string | null
          room_type?: string | null
          service_charge: number
          subtotal: number
          total_amount: number
          updated_at?: string
          user_id: string
          vehicle_id?: string | null
        }
        Update: {
          board_type?: string | null
          booking_status?: string
          booking_type?: string
          check_in_date?: string | null
          check_out_date?: string | null
          created_at?: string
          estimated_km?: number | null
          hotel_id?: string | null
          id?: string
          number_of_nights?: number | null
          number_of_persons?: number | null
          payment_method?: string
          rental_end_date?: string | null
          rental_start_date?: string | null
          room_type?: string | null
          service_charge?: number
          subtotal?: number
          total_amount?: number
          updated_at?: string
          user_id?: string
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bookings_hotel_id_fkey"
            columns: ["hotel_id"]
            isOneToOne: false
            referencedRelation: "hotels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      destinations: {
        Row: {
          city: string | null
          created_at: string
          description: string
          id: string
          image_url: string | null
          interest_category: string
          name: string
        }
        Insert: {
          city?: string | null
          created_at?: string
          description: string
          id?: string
          image_url?: string | null
          interest_category: string
          name: string
        }
        Update: {
          city?: string | null
          created_at?: string
          description?: string
          id?: string
          image_url?: string | null
          interest_category?: string
          name?: string
        }
        Relationships: []
      }
      favorite_places: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          place_name: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          place_name: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          place_name?: string
          user_id?: string
        }
        Relationships: []
      }
      hotels: {
        Row: {
          category: string
          city: string
          created_at: string
          hotel_name: string
          id: string
          image_url: string | null
          owner_email: string | null
          per_night_charge: number
          stars: number
          updated_at: string
          user_id: string
        }
        Insert: {
          category: string
          city: string
          created_at?: string
          hotel_name: string
          id?: string
          image_url?: string | null
          owner_email?: string | null
          per_night_charge: number
          stars: number
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: string
          city?: string
          created_at?: string
          hotel_name?: string
          id?: string
          image_url?: string | null
          owner_email?: string | null
          per_night_charge?: number
          stars?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          country: string | null
          created_at: string
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          country?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          country?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      role_requests: {
        Row: {
          admin_notes: string | null
          created_at: string
          id: string
          requested_role: Database["public"]["Enums"]["app_role"]
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_notes?: string | null
          created_at?: string
          id?: string
          requested_role: Database["public"]["Enums"]["app_role"]
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_notes?: string | null
          created_at?: string
          id?: string
          requested_role?: Database["public"]["Enums"]["app_role"]
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      saved_itineraries: {
        Row: {
          created_at: string
          days: number
          guests: number | null
          id: string
          interests: Json
          itinerary_data: Json
          title: string
          user_id: string
        }
        Insert: {
          created_at?: string
          days: number
          guests?: number | null
          id?: string
          interests: Json
          itinerary_data: Json
          title: string
          user_id: string
        }
        Update: {
          created_at?: string
          days?: number
          guests?: number | null
          id?: string
          interests?: Json
          itinerary_data?: Json
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      travel_reviews: {
        Row: {
          created_at: string
          id: string
          place_name: string
          rating: number
          review_text: string | null
          updated_at: string
          user_id: string
          visit_date: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          place_name: string
          rating: number
          review_text?: string | null
          updated_at?: string
          user_id: string
          visit_date?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          place_name?: string
          rating?: number
          review_text?: string | null
          updated_at?: string
          user_id?: string
          visit_date?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vehicle_classes: {
        Row: {
          class_name: string
          created_at: string
          description: string | null
          id: string
          price_multiplier: number | null
          vehicle_type_id: string
        }
        Insert: {
          class_name: string
          created_at?: string
          description?: string | null
          id?: string
          price_multiplier?: number | null
          vehicle_type_id: string
        }
        Update: {
          class_name?: string
          created_at?: string
          description?: string | null
          id?: string
          price_multiplier?: number | null
          vehicle_type_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_classes_vehicle_type_id_fkey"
            columns: ["vehicle_type_id"]
            isOneToOne: false
            referencedRelation: "vehicle_types"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicle_types: {
        Row: {
          created_at: string
          description: string | null
          id: string
          max_passengers: number
          min_passengers: number
          name: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          max_passengers: number
          min_passengers: number
          name: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          max_passengers?: number
          min_passengers?: number
          name?: string
        }
        Relationships: []
      }
      vehicles: {
        Row: {
          created_at: string
          id: string
          image_url: string | null
          model: string
          owner_email: string | null
          per_km_charge: number
          updated_at: string
          user_id: string
          vehicle_category: string | null
          vehicle_number: string
          vehicle_type: string
        }
        Insert: {
          created_at?: string
          id?: string
          image_url?: string | null
          model: string
          owner_email?: string | null
          per_km_charge: number
          updated_at?: string
          user_id: string
          vehicle_category?: string | null
          vehicle_number: string
          vehicle_type: string
        }
        Update: {
          created_at?: string
          id?: string
          image_url?: string | null
          model?: string
          owner_email?: string | null
          per_km_charge?: number
          updated_at?: string
          user_id?: string
          vehicle_category?: string | null
          vehicle_number?: string
          vehicle_type?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_exists: { Args: never; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "user" | "driver" | "hotel_owner"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user", "driver", "hotel_owner"],
    },
  },
} as const
